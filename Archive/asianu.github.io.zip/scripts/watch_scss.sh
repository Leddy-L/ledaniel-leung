# Watches all scss files and automatically turn them into css files.
cd ..
sass --no-source-map --trace --watch scss:css
